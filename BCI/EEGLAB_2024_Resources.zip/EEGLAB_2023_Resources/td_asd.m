%% Open data files
td101 = csvread('TD101_raw_256.csv', 1, 0);
td101_T = transpose(td101)