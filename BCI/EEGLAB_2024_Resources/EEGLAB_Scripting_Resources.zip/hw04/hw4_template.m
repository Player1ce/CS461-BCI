global totalEpochs
totalEpochs = 109;

global sampleRate
sampleRate = 220;


%saveEpochs(1,4)
%compareBandPower(32)
%getHighestAlpha()

% Create a matlab function that generates and saves line plots of 3 epochs
% (4 channels per epoch). The function should save a total of 12 images.
function saveEpochs(numEpochs, numChannels)

end



% Complete the function below to generate 4 bar plots that compares delta, theta, alpha, and beta band
% power of 1 epoch. Each bar plot should reflect a different channel.
function compareBandPower(epochNumber)

end

% Create a matlab function that finds the epoch with the highest alpha
% power in channel. The function should print out the epoch number and
% alpha value.
function getHighestAlpha()

end
