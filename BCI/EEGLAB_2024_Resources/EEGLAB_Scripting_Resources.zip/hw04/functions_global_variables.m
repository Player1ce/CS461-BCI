global x;
x = 0.9;
foo()

function foo()
    global x
    disp(x);
end
